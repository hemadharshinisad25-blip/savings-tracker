import React, { useMemo, useState } from "react";
import {
  Target, Clock3, CheckCircle2, WalletCards, Plus, Trash2, X,
  PiggyBank, CalendarDays, ArrowUpRight
} from "lucide-react";

const STORAGE_KEY = "savings-goals-v1";

const starterGoals = [
  {
    id: crypto.randomUUID(),
    name: "Fees",
    description: "For daughter",
    target: 50000,
    saved: 100,
    targetDate: new Date(Date.now() + 86400000).toISOString().slice(0, 10),
    completed: false
  }
];

function loadGoals() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? JSON.parse(saved) : starterGoals;
  } catch {
    return starterGoals;
  }
}

function money(value) {
  return new Intl.NumberFormat("en-US", {
    style: "currency", currency: "USD", minimumFractionDigits: 2
  }).format(value);
}

function daysLeft(dateString) {
  const today = new Date();
  today.setHours(0,0,0,0);
  const date = new Date(dateString + "T00:00:00");
  return Math.ceil((date - today) / 86400000);
}

function App() {
  const [goals, setGoals] = useState(loadGoals);
  const [showGoalModal, setShowGoalModal] = useState(false);
  const [showContribution, setShowContribution] = useState(null);

  const persist = (next) => {
    setGoals(next);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  };

  const stats = useMemo(() => {
    const total = goals.reduce((s, g) => s + Number(g.target), 0);
    const saved = goals.reduce((s, g) => s + Number(g.saved), 0);
    const completed = goals.filter(g => g.completed || g.saved >= g.target).length;
    const active = goals.length - completed;
    return { totalGoals: goals.length, active, completed, saved, target: total };
  }, [goals]);

  const addGoal = (goal) => {
    persist([{ ...goal, id: crypto.randomUUID(), saved: 0, completed: false }, ...goals]);
    setShowGoalModal(false);
  };

  const addContribution = (id, amount) => {
    const next = goals.map(g => {
      if (g.id !== id) return g;
      const saved = Math.min(Number(g.target), Number(g.saved) + amount);
      return { ...g, saved, completed: saved >= Number(g.target) };
    });
    persist(next);
    setShowContribution(null);
  };

  const removeGoal = (id) => {
    if (confirm("Delete this savings goal?")) persist(goals.filter(g => g.id !== id));
  };

  const overallPercent = stats.target ? Math.min(100, (stats.saved / stats.target) * 100) : 0;
  const activeGoals = goals.filter(g => !(g.completed || g.saved >= g.target));
  const completedGoals = goals.filter(g => g.completed || g.saved >= g.target);

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">
          <div className="brand-icon"><PiggyBank size={22}/></div>
          <div>
            <h1>SavingsGoal</h1>
            <p>Track your financial goals</p>
          </div>
        </div>
        <button className="primary-btn" onClick={() => setShowGoalModal(true)}>
          <Plus size={18}/> New Goal
        </button>
      </header>

      <main className="container">
        <section className="stat-grid">
          <Stat icon={<Target/>} label="Total Goals" value={stats.totalGoals} tone="blue"/>
          <Stat icon={<Clock3/>} label="Active" value={stats.active} tone="orange"/>
          <Stat icon={<CheckCircle2/>} label="Completed" value={stats.completed} tone="green"/>
          <Stat icon={<WalletCards/>} label="Total Saved" value={money(stats.saved)} tone="cyan"/>
        </section>

        <section className="overall-card">
          <div className="overall-head">
            <div>
              <h2>Overall Progress</h2>
              <p>{money(stats.saved)} of {money(stats.target)}</p>
            </div>
            <div className="overall-number">
              <strong>{overallPercent.toFixed(1)}%</strong>
              <span>{money(Math.max(0, stats.target - stats.saved))} remaining</span>
            </div>
          </div>
          <div className="progress"><div style={{width: `${overallPercent}%`}}/></div>
        </section>

        <section className="goal-section">
          <div className="section-title active-title">
            <Clock3 size={20}/> Active Goals <span>({activeGoals.length})</span>
          </div>
          {activeGoals.length === 0 ? (
            <Empty text="No active goals. Create a new goal to get started."/>
          ) : (
            <div className="goal-list">
              {activeGoals.map(goal => (
                <GoalCard key={goal.id} goal={goal} onDelete={removeGoal}
                  onContribute={() => setShowContribution(goal)}/>
              ))}
            </div>
          )}
        </section>

        <section className="goal-section">
          <div className="section-title completed-title">
            <CheckCircle2 size={20}/> Completed Goals <span>({completedGoals.length})</span>
          </div>
          {completedGoals.length === 0 ? (
            <Empty text="Completed goals will appear here."/>
          ) : (
            <div className="goal-list">
              {completedGoals.map(goal => (
                <GoalCard key={goal.id} goal={goal} onDelete={removeGoal}
                  onContribute={() => {}}/>
              ))}
            </div>
          )}
        </section>
      </main>

      {showGoalModal && <GoalModal onClose={() => setShowGoalModal(false)} onSave={addGoal}/>}
      {showContribution && (
        <ContributionModal
          goal={showContribution}
          onClose={() => setShowContribution(null)}
          onSave={(amount) => addContribution(showContribution.id, amount)}
        />
      )}
    </div>
  );
}

function Stat({icon, label, value, tone}) {
  return <div className="stat-card">
    <div className={`stat-icon ${tone}`}>{icon}</div>
    <div><span>{label}</span><strong>{value}</strong></div>
  </div>
}

function GoalCard({goal, onDelete, onContribute}) {
  const percent = Math.min(100, (Number(goal.saved) / Number(goal.target)) * 100);
  const remaining = Math.max(0, Number(goal.target) - Number(goal.saved));
  const complete = goal.completed || goal.saved >= goal.target;
  const days = daysLeft(goal.targetDate);

  return <article className="goal-card">
    <div className="goal-top">
      <div className="goal-name">
        <div className="goal-icon"><Target size={19}/></div>
        <div>
          <h3>{goal.name}</h3>
          <div className="badges">
            <span className={`badge ${complete ? "complete" : "active"}`}>
              {complete ? <CheckCircle2 size={13}/> : <Clock3 size={13}/>}
              {complete ? "Completed" : "Active"}
            </span>
            {!complete && <span className="date-badge"><CalendarDays size={13}/>
              {days < 0 ? "Overdue" : `${days} ${days === 1 ? "day" : "days"} left`}
            </span>}
          </div>
        </div>
      </div>
      <button className="icon-btn delete" onClick={() => onDelete(goal.id)} title="Delete goal"><Trash2 size={17}/></button>
    </div>

    {goal.description && <div className="description">▤ &nbsp;{goal.description}</div>}

    <div className="goal-values">
      <div><span>Target</span><strong>{money(goal.target)}</strong></div>
      <div><span>Saved</span><strong className="saved">{money(goal.saved)}</strong></div>
      <div><span>Remaining</span><strong>{money(remaining)}</strong></div>
      <div><span>Target Date</span><strong>{new Date(goal.targetDate + "T00:00:00").toLocaleDateString()}</strong></div>
    </div>

    <div className="goal-progress-row">
      <div className="progress small"><div style={{width: `${percent}%`}}/></div>
      <strong>{percent.toFixed(1)}%</strong>
    </div>

    {!complete && <button className="contribute-btn" onClick={onContribute}>
      <ArrowUpRight size={17}/> Add Contribution
    </button>}
  </article>
}

function Empty({text}) {
  return <div className="empty">{text}</div>
}

function GoalModal({onClose, onSave}) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [target, setTarget] = useState("");
  const [date, setDate] = useState("");

  const submit = (e) => {
    e.preventDefault();
    if (!name.trim() || !target || !date) return;
    onSave({name: name.trim(), description: description.trim(), target: Number(target), targetDate: date});
  };

  return <Modal title="Create New Goal" onClose={onClose}>
    <form onSubmit={submit}>
      <label>Goal Name<input value={name} onChange={e=>setName(e.target.value)} placeholder="e.g. New Laptop" required/></label>
      <label>Description<input value={description} onChange={e=>setDescription(e.target.value)} placeholder="What are you saving for?"/></label>
      <div className="form-row">
        <label>Target Amount<input type="number" min="1" step="0.01" value={target} onChange={e=>setTarget(e.target.value)} placeholder="50000" required/></label>
        <label>Target Date<input type="date" value={date} onChange={e=>setDate(e.target.value)} required/></label>
      </div>
      <div className="modal-actions"><button type="button" className="secondary-btn" onClick={onClose}>Cancel</button><button className="primary-btn">Create Goal</button></div>
    </form>
  </Modal>
}

function ContributionModal({goal, onClose, onSave}) {
  const [amount, setAmount] = useState("");
  const submit = (e) => {
    e.preventDefault();
    const n = Number(amount);
    if (n > 0) onSave(n);
  };
  return <Modal title={`Add Contribution — ${goal.name}`} onClose={onClose}>
    <form onSubmit={submit}>
      <div className="contribution-info">Current saved: <strong>{money(goal.saved)}</strong><br/>Remaining: <strong>{money(Math.max(0, goal.target-goal.saved))}</strong></div>
      <label>Contribution Amount<input autoFocus type="number" min="0.01" step="0.01" value={amount} onChange={e=>setAmount(e.target.value)} placeholder="1000" required/></label>
      <div className="modal-actions"><button type="button" className="secondary-btn" onClick={onClose}>Cancel</button><button className="primary-btn">Add Contribution</button></div>
    </form>
  </Modal>
}

function Modal({title, children, onClose}) {
  return <div className="overlay" onMouseDown={e=>e.target===e.currentTarget && onClose()}>
    <div className="modal">
      <div className="modal-head"><h2>{title}</h2><button className="icon-btn" onClick={onClose}><X/></button></div>
      {children}
    </div>
  </div>
}

export default App;