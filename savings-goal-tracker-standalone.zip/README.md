# Savings Goal Tracker

This is a standalone React/Vite recreation of the SavingsGoal prototype shown in the supplied screenshot and public prototype page.

## Run locally

1. Install Node.js.
2. Open a terminal in this folder.
3. Run:
   npm install
   npm run dev
4. Open the local URL printed by Vite.

## Included
- Dashboard statistics
- Overall progress
- Create new savings goals
- Target amount and target date
- Add contributions
- Automatic saved/remaining/progress calculations
- Active and completed goal sections
- Delete goals
- Browser localStorage persistence
- Responsive layout

The project is independent of Bolt branding and does not add a "Made in Bolt" badge.
